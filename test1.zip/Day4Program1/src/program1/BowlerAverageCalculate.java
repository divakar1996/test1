package program1;

import java.util.Scanner;

public class BowlerAverageCalculate {
	private int noOfBowlers;
	private double avarage[];
	private int count;

	private String input2[];
	private int sum;
	private double avg;
	
	Scanner scanner = new Scanner(System.in);
	

	public int getNoOfBowlers() {
		return noOfBowlers;
	}

	public void setNoOfBowlers(int noOfBowlers) {
		this.noOfBowlers = noOfBowlers;
	}

	public BowlerAverageCalculate(int noOfBowlers) {
		super();
		this.noOfBowlers = noOfBowlers;
		input2 = new String[noOfBowlers];
	}

	public void init() {
		for (int i = 0; i < input2.length; i++) {
			input2[i] = scanner.nextLine();

		}
	}

	public void calculate() {
		int i;
		for ( i = 0; i < input2.length; i++) {
			char[] a = input2[i].toCharArray();
			int chageIntoInt[] = new int[a.length];
			for (int j = 0; j < chageIntoInt.length; j++) {
				chageIntoInt[j] = Character.getNumericValue(a[j]);
				sum += chageIntoInt[j];
			}
			avg = (double) (sum / chageIntoInt.length);
			avarage=new double[input2.length];
			avarage[i] = avg;

		}
		for(i=0;i<avarage.length;i++) {
			if(avarage[i]>5) {
			count++;
			}
		}
		System.out.println("No of bowlers who selected in the list :"+count);

		
	}
	

}

